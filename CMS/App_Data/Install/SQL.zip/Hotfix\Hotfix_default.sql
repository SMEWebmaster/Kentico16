-- HFA-9 - SQL error when creating global category
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
UPDATE [CMS_Class]
SET [ClassFormDefinition]
= 
'<form version="2">
  <field column="CategoryID" columntype="integer" fieldtype="CustomUserControl" isPK="true" system="true" publicfield="false" guid="a7e6de80-6774-4fc9-8764-fde25832fce0" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryID</fieldcaption>
    </properties>
    <settings>
      <controlname>labelcontrol</controlname>
    </settings>
  </field>
  <field column="CategorySiteID" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="55f19a7f-1e83-4f11-8dcd-b15e2c5e2638" visibility="none" reftype="Required">
    <properties>
      <fielddescription>{$category.categorysiteid.description$}</fielddescription>
      <defaultvalue ismacro="true">{%Form.ObjectSiteID &gt; 0 ? Form.ObjectSiteID : "" @%}</defaultvalue>
      <fieldcaption>{$category_edit.categorysite$}</fieldcaption>
    </properties>
    <settings>
      <RepeatDirection>horizontal</RepeatDirection>
      <controlname>RadioButtonsControl</controlname>
      <RepeatLayout>Flow</RepeatLayout>
      <Options>{%Form.ObjectSiteID @%};{$category_edit.sitecategory$}
;{$category_edit.globalcategory$}</Options>
    </settings>
  </field>
  <field column="CategoryDisplayName" visible="true" columntype="text" fieldtype="CustomUserControl" system="true" columnsize="250" publicfield="false" guid="62f59aab-9b3e-4ddc-8f7a-fb97e039de40" visibility="none" translatefield="true" reftype="Required">
    <properties>
      <fielddescription>{$category.categorydisplayname.description$}</fielddescription>
      <fieldcaption>{$general.displayname$}</fieldcaption>
    </properties>
    <settings>
      <controlname>localizabletextbox</controlname>
      <ValueIsContent>False</ValueIsContent>
    </settings>
  </field>
  <field column="CategoryName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="250" publicfield="false" guid="6ec936dc-3b0f-476c-8d07-9dbb7e5a19b9" visibility="none" isunique="true" reftype="Required">
    <properties>
      <fielddescription>{$category.categoryname.description$}</fielddescription>
      <fieldcaption>{$general.codename$}</fieldcaption>
    </properties>
    <settings>
      <controlname>codename</controlname>
    </settings>
  </field>
  <field column="CategoryParentID" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="70e95a64-6c83-4dc3-a334-c8a7bf61ea39" visibility="none" reftype="Required">
    <properties>
      <visiblemacro ismacro="true">{%FormMode == FormModeEnum.Update @%}</visiblemacro>
      <fielddescription>{$category.categoryparentid.description$}</fielddescription>
      <fieldcaption>{$category_edit.parentcategory$}</fieldcaption>
    </properties>
    <settings>
      <controlname>category_sparentselector</controlname>
      <AddRootRecord>True</AddRootRecord>
    </settings>
  </field>
  <field column="CategoryDescription" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="21b4dc27-69d2-4ee5-ad21-31ce7362a169" visibility="none" translatefield="true" reftype="Required">
    <properties>
      <fielddescription>{$category.categorydescription.description$}</fielddescription>
      <fieldcaption>{$general.description$}</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Wrap>True</Wrap>
      <IsTextArea>True</IsTextArea>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <controlname>textareacontrol</controlname>
      <FilterMode>False</FilterMode>
    </settings>
  </field>
  <field column="CategoryEnabled" visible="true" columntype="boolean" fieldtype="CustomUserControl" system="true" publicfield="false" guid="60a19437-daca-476d-a9c7-f771810012d2" visibility="none" reftype="Required">
    <properties>
      <fielddescription>{$category.categoryenabled.description$}</fielddescription>
      <defaultvalue>True</defaultvalue>
      <fieldcaption>{$general.enabled$}</fieldcaption>
    </properties>
    <settings>
      <controlname>checkboxcontrol</controlname>
    </settings>
  </field>
  <field column="CategoryCount" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="d333614c-e26b-45fa-803f-2815644d9b6e" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryEnabled</fieldcaption>
    </properties>
    <settings>
      <controlname>checkboxcontrol</controlname>
    </settings>
  </field>
  <field column="CategoryUserID" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="aebc6d41-6911-4955-8566-3e46053d2243" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryUserID</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <FilterMode>False</FilterMode>
      <controlname>textboxcontrol</controlname>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
    </settings>
  </field>
  <field column="CategoryGUID" columntype="guid" fieldtype="CustomUserControl" system="true" publicfield="false" guid="09d6706d-6145-400c-9e12-c47f14fdfa44" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryGUID</fieldcaption>
    </properties>
    <settings>
      <controlname>LabelControl</controlname>
    </settings>
  </field>
  <field column="CategoryLastModified" columntype="datetime" fieldtype="CustomUserControl" system="true" publicfield="false" guid="67e9377c-c25a-4dd7-9ef8-9b9d97a408ce" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryLastModified</fieldcaption>
    </properties>
    <settings>
      <controlname>calendarcontrol</controlname>
    </settings>
  </field>
  <field column="CategoryIDPath" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="450" publicfield="false" guid="aac5e74e-aa14-43b5-b18c-fd329ba7974c" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryIDPath</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <controlname>textboxcontrol</controlname>
      <FilterMode>False</FilterMode>
    </settings>
  </field>
  <field column="CategoryNamePath" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="1500" publicfield="false" guid="1591d49a-9209-4d55-851c-9fe1769e9def" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryNamePath</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <FilterMode>False</FilterMode>
      <controlname>textboxcontrol</controlname>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
    </settings>
  </field>
  <field column="CategoryLevel" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="359e5923-49da-4a39-9910-b9458d5a40a2" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryLevel</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <controlname>textboxcontrol</controlname>
      <FilterMode>False</FilterMode>
    </settings>
  </field>
  <field column="CategoryOrder" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="3b0a29ce-b93f-4ff8-a86b-5273a4ad1336" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryOrder</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <FilterMode>False</FilterMode>
      <controlname>textboxcontrol</controlname>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
    </settings>
  </field>
</form>'
WHERE [ClassName] LIKE 'cms.category'
END
GO

-- HFA-51 - Old warning message is shown for root deletion in Pages app
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 3
BEGIN
	DECLARE @StringID INT;
	SET @StringID = (SELECT StringID FROM CMS_ResourceString WHERE StringKey = 'delete.rootwarning' AND StringIsCustom = 0)
	IF (@StringID > 0)
	BEGIN
		DELETE FROM CMS_ResourceTranslation WHERE TranslationStringID = @StringID
		DELETE FROM CMS_ResourceString WHERE StringID = @StringID
	END
END
GO

-- HFA-70 - Web farm servers were not removed when scaling down on Microsoft Azure
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 5
BEGIN
	IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_WebFarmSync_SetServerTasks' AND [ROUTINE_TYPE]= N'PROCEDURE')
	BEGIN
		DROP PROCEDURE [Proc_CMS_WebFarmSync_SetServerTasks]
	END
	IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_WebFarmTask_UpdateTaskEnable' AND [ROUTINE_TYPE]= N'PROCEDURE')
	BEGIN
		DROP PROCEDURE [Proc_CMS_WebFarmTask_UpdateTaskEnable]
	END

	IF NOT EXISTS (SELECT 1 FROM [CMS_Query] WHERE [QueryGUID] = 'c0077aa8-23a0-47d4-a746-1391e95edb37') 
	BEGIN
		DECLARE @classID int;
		SET @classID = (SELECT TOP 1 [ClassID] FROM [CMS_Class] WHERE [ClassName] = 'cms.WebFarmServer')
		IF @classID <> 0 BEGIN
			INSERT [CMS_Query] ([QueryName], [QueryTypeID], [QueryText], [QueryRequiresTransaction], [ClassID], [QueryIsLocked], [QueryLastModified], [QueryGUID], [QueryLoadGeneration], [QueryIsCustom], [QueryConnectionString]) 
			VALUES ('delete', 1, 'Proc_CMS_WebFarmServer_Delete', 0, @classID, 0, getDate(), 'c0077aa8-23a0-47d4-a746-1391e95edb37', 0, 0, 'CMSConnectionString')
		END
	END
END
GO

ALTER PROCEDURE [Proc_CMS_WebFarmTask_Insert]
@TaskType nvarchar(50), 
@TaskTextData ntext, 
@TaskCreated datetime,
@TaskMachineName nvarchar(450),
@TaskTarget nvarchar(450),
@TaskBinary image,
@TaskIsAnonymous bit,
@TargetServerId int,
@CurrentServerId int
AS
BEGIN
	DECLARE @taskId int;
	BEGIN TRANSACTION
		INSERT INTO [CMS_WebFarmTask] ( [TaskType], [TaskTextData], [TaskBinaryData], [TaskCreated], [TaskEnabled], [TaskMachineName], [TaskTarget], [TaskIsAnonymous]) VALUES ( @TaskType, @TaskTextData, @TaskBinary, @TaskCreated, 1, @TaskMachineName, @TaskTarget, @TaskIsAnonymous ); 
		SELECT @taskId = SCOPE_IDENTITY();
	
		IF(@TaskIsAnonymous = 0) BEGIN
			IF(@TargetServerId > 0) BEGIN
				INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] ) VALUES ( @TargetServerId, @taskId );
			END
			ELSE BEGIN
				INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] ) SELECT ServerID, @taskId FROM [CMS_WebFarmServer] WHERE ServerID <> @CurrentServerId;
			END
		END
	COMMIT
END
GO
	
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_WebFarmServer_Delete' AND [ROUTINE_TYPE]= N'PROCEDURE')
	DROP PROCEDURE [Proc_CMS_WebFarmServer_Delete]
GO
CREATE PROCEDURE [Proc_CMS_WebFarmServer_Delete] 
@ID int
AS
BEGIN
	BEGIN TRANSACTION
		-- Remove all task - server binding
		DELETE FROM [CMS_WebFarmServerTask] WHERE ServerId = @ID;
		-- Remove server
		DELETE FROM [CMS_WebFarmServer] WHERE ServerId = @ID;
	COMMIT
	-- Remove all unasigned tasks
	DELETE FROM CMS_WebFarmTask WHERE TaskEnabled = 1 AND TaskIsAnonymous = 0 AND TaskID NOT IN (SELECT TaskID FROM CMS_WebFarmServerTask);
END
GO


-- HFA-101 - form control used for Inherits from page type property in Page types application filtered data based on current site
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 6
BEGIN
UPDATE [CMS_AlternativeForm]
SET [FormDefinition]='<form version="2"><category name="general.general" dummy="true" order="1"><properties><caption>{$general.general$}</caption><visible>True</visible></properties></category><field column="ClassDisplayName" order="2"><settings><ValueIsContent>False</ValueIsContent><controlname>localizabletextbox</controlname><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /><AutoCompleteEnableCaching /></settings><properties><fielddescription>{$documenttype.classdisplayname.description$}</fielddescription></properties></field><field column="ClassName" order="3"><settings><ResourcePrefix>documenttype.edit</ResourcePrefix></settings><properties><fielddescription>{$documenttype.classname.description$}</fielddescription><validationerrormessage /></properties></field><field column="ClassUsesVersioning" order="4" /><field column="ClassIsDocumentType" order="5" /><field column="ClassIsCoupledClass" order="6" /><field column="ClassXmlSchema" order="7" /><field column="ClassFormDefinition" order="8" /><field column="ClassNodeNameSource" order="9" /><field column="ClassTableName" order="10"><settings><controlname>labelcontrol</controlname><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /><AutoCompleteEnableCaching /></settings><properties><visiblemacro ismacro="true">{%ClassIsCoupledClass%}</visiblemacro><fielddescription>{$documenttype.classtablename.description$}</fielddescription></properties></field><field column="ClassInheritsFromClassID" visible="true" order="11"><settings><MaxDisplayedTotalItems>50</MaxDisplayedTotalItems><AllowAll>False</AllowAll><EditDialogWindowHeight>700</EditDialogWindowHeight><controlname>Uni_selector</controlname><AddGlobalObjectNamePrefix>False</AddGlobalObjectNamePrefix><ReturnColumnName>ClassID</ReturnColumnName><WhereCondition ismacro="True">ClassIsCoupledClass = 1 AND ClassID &lt;&gt; {%ClassID%} AND (ClassInheritsFromClassID IS NULL OR ClassInheritsFromClassID &lt;&gt; {%ClassID%})</WhereCondition><RemoveMultipleCommas>False</RemoveMultipleCommas><EditDialogWindowWidth>1000</EditDialogWindowWidth><AllowDefault>False</AllowDefault><DialogWindowName>SelectionDialog</DialogWindowName><MaxDisplayedItems>25</MaxDisplayedItems><ObjectType>cms.documenttype</ObjectType><LocalizeItems>True</LocalizeItems><ItemsPerPage>25</ItemsPerPage><AddGlobalObjectSuffix>False</AddGlobalObjectSuffix><UseAutocomplete>False</UseAutocomplete><EncodeOutput>True</EncodeOutput><AllowEmpty>True</AllowEmpty><DisplayNameFormat>{%ClassDisplayName%}</DisplayNameFormat><EditWindowName>EditWindow</EditWindowName><AllowEditTextBox>False</AllowEditTextBox><SelectionMode>1</SelectionMode><GlobalObjectSuffix ismacro="True">{$general.global$}</GlobalObjectSuffix><ValuesSeparator>;</ValuesSeparator><ReturnColumnType>id</ReturnColumnType></settings><properties><fielddescription>{$documenttype.classinheritsfromclassid.description$}</fielddescription><visiblemacro ismacro="true">{%ClassIsCoupledClass%}</visiblemacro><fieldcaption>{$DocumentType.InheritsFrom$}</fieldcaption></properties></field><field column="ClassIconClass" visible="true" spellcheck="false" order="12"><settings><controlname>documenttypeiconselector</controlname></settings><properties><fielddescription>{$documenttype.classicons.description$}</fielddescription><fieldcaption>{$documenttype.icon$}</fieldcaption></properties></field><category name="DocumentType.NewSettings" dummy="true" order="13"><properties><caption>{$DocumentType.NewSettings$}</caption><visible>True</visible></properties></category><field column="ClassNewPageUrl" visible="true" order="14"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classnewpageurl.description$}</fielddescription><fieldcaption>{$documenttype_edit_general.newpage$}</fieldcaption></properties></field><field column="ClassShowTemplateSelection" visible="true" hasdependingfields="true" order="15"><properties><fielddescription>{$documenttype.classshowtemplateselection.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.TemplateSelection$}</fieldcaption></properties></field><field column="ClassPageTemplateCategoryID" visible="true" hasdependingfields="true" dependsonanotherfield="true" order="16"><settings><ShowEmptyCategories>False</ShowEmptyCategories><controlname>pagetemplatecategoryselector</controlname><WhereCondition>CategoryName != ''AdHoc'' AND CategoryPath NOT LIKE ''UITemplates%''</WhereCondition></settings><properties><visiblemacro ismacro="true">{%ClassShowTemplateSelection%}</visiblemacro><fielddescription>{$documenttype.classpagetemplatecategoryid.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.TemplateCategorySelection$}</fieldcaption></properties></field><field column="ClassDefaultPageTemplateID" visible="true" order="17"><settings><ReturnColumnName>PageTemplateID</ReturnColumnName><RootCategoryName>/</RootCategoryName><ShowTemplateButtons>False</ShowTemplateButtons><ShowTemplates>True</ShowTemplates><ShowOnlySiteTemplates>False</ShowOnlySiteTemplates><controlname>selectpagetemplate</controlname></settings><properties><fielddescription>{$documenttype.classdefaultpagetemplateid.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.DefaultTemplate$}</fieldcaption></properties></field><field column="ClassFormLayout" order="18" /><category name="DocumentType.EditingSettings" dummy="true" order="19"><properties><caption>{$DocumentType.EditingSettings$}</caption><visible>True</visible></properties></category><field column="ClassViewPageUrl" visible="true" order="20"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classviewpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.ViewPage$}</fieldcaption></properties></field><field column="ClassEditingPageUrl" order="21"><settings><FilterMode>False</FilterMode></settings><properties><fielddescription>{$documenttype.classeditingpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.EditingPage$}</fieldcaption></properties></field><field column="ClassPreviewPageUrl" visible="true" order="22"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classpreviewpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.PreviewPage$}</fieldcaption></properties></field><field column="ClassListPageUrl" visible="true" order="23"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classlistpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.ListPage$}</fieldcaption></properties></field><category name="documenttype.advanced" dummy="true" order="24"><properties><caption>{$documenttype.advanced$}</caption><visible>True</visible></properties></category><field column="ClassShowAsSystemTable" visible="" order="25" /><field column="ClassUsePublishFromTo" visible="true" order="26"><properties><fielddescription>{$documenttype.classusepublishfromto.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.UsePublishFromTo$}</fieldcaption></properties></field><field column="ClassSKUMappings" order="27" /><field column="ClassIsMenuItemType" visible="true" order="28"><properties><validationerrormessage>{$sysdev.class_edit_gen.displayname$}</validationerrormessage><fielddescription>{$documenttype.classismenuitemtype.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.IsMenuItem$}</fieldcaption></properties></field><field column="ClassNodeAliasSource" order="29" /><field column="ClassLastModified" order="30" /><field column="ClassGUID" order="31" /><field column="ClassCreateSKU" order="32" /><field column="ClassIsProduct" order="33" /><field column="ClassIsCustomTable" order="34" /><field column="ClassShowColumns" order="35" /><field column="ClassLoadGeneration" order="36"><properties><fielddescription>{$documenttype.classloadgeneration.description$}</fielddescription></properties></field><field column="ClassSearchTitleColumn" order="37" /><field column="ClassSearchContentColumn" order="38" /><field column="ClassSearchImageColumn" order="39" /><field column="ClassSearchCreationDateColumn" order="40" /><field column="ClassSearchSettings" order="41" /><field column="ClassConnectionString" visible="" order="42" /><field column="ClassSearchEnabled" order="43" /><field column="ClassSKUDefaultDepartmentName" order="44" /><field column="ClassSKUDefaultDepartmentID" order="45" /><field column="ClassContactMapping" order="46" /><field column="ClassContactOverwriteEnabled" order="47" /><field column="ClassSKUDefaultProductType" order="48" /><field column="ClassIsProductSection" order="49" /><field column="ClassFormLayoutType" order="50" /><field column="ClassVersionGUID" order="51" /><field column="ClassDefaultObjectType" order="52" /><field column="ClassIsForm" order="53" /><field column="ClassResourceID" visible="" order="54" /><field column="ClassCustomizedColumns" order="55" /><field column="ClassCodeGenerationSettings" order="56" /></form>'
WHERE [FormName] LIKE 'DocumentType'
END
GO

-- HFA 133 - Validation rule for transformation name (field TransformationName) was too restrictive
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 7
BEGIN
UPDATE [CMS_Class]
SET [ClassFormDefinition]
= '<form version="2"><field column="TransformationID" visible="true" columntype="integer" fieldtype="CustomUserControl" isPK="true" system="true" publicfield="false" guid="15f5489f-158e-434c-b8a8-3b246917aa3a" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationID</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="TransformationName" visible="true" columntype="text" fieldtype="CustomUserControl" system="true" columnsize="100" publicfield="false" guid="8f32aaee-ed30-464d-b321-d5b1f8779039" visibility="none" translatefield="true" reftype="Required"><properties><validationerrormessage>{$documenttype_edit.transformationnameformat$}</validationerrormessage><fieldcaption>TransformationName</fieldcaption></properties><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>TextBoxControl</controlname></settings><rules><rule>{%Rule("Value.Matches(\"^[A-Za-z_][A-Za-z0-9_-]+$\")", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"RegExp\" &gt;&lt;p n=\"regexp\"&gt;&lt;t&gt;^[A-Za-z_][A-Za-z0-9_-]+$&lt;/t&gt;&lt;v&gt;^[A-Za-z_][A-Za-z0-9_-]+$&lt;/v&gt;&lt;r&gt;0&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;text&lt;/vt&gt;&lt;tv&gt;0&lt;/tv&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")@%}</rule></rules></field><field column="TransformationCode" visible="true" columntype="longtext" fieldtype="CustomUserControl" system="true" publicfield="false" guid="87c280d1-e998-451b-9dfb-8cbbd2891b0a" translatefield="true" reftype="Required"><properties><fieldcaption>Transformation code</fieldcaption></properties><settings><Trim>False</Trim><controlname>textboxcontrol</controlname><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="TransformationType" visible="true" columntype="text" fieldtype="CustomUserControl" system="true" columnsize="50" publicfield="false" guid="12c4729c-16f6-4565-8509-2db6af52df99" translatefield="true" reftype="Required"><properties><fieldcaption>Transformation type</fieldcaption></properties><settings><Trim>False</Trim><controlname>textboxcontrol</controlname><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="TransformationClassID" visible="true" columntype="integer" fieldtype="CustomUserControl" system="true" publicfield="false" guid="72b254ff-a179-46f9-851e-c968e8324328" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationClassID</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="TransformationCSS" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="38e823cd-030a-41b2-b64a-8e680d40c6b7" visibility="none" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationCSS</fieldcaption></properties><settings><controlname>textareacontrol</controlname><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="TransformationVersionGUID" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="50" publicfield="false" guid="e269354c-1f6e-4e55-8158-73d059b01941" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationVersionGUID</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="TransformationGUID" visible="true" columntype="guid" fieldtype="CustomUserControl" system="true" publicfield="false" guid="6a375a9a-04d7-4592-8df8-acc1f5127249" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationGUID</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="TransformationLastModified" visible="true" columntype="datetime" fieldtype="CustomUserControl" system="true" publicfield="false" guid="c19c9cd6-60e5-40de-b547-dd045a32c3de" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationLastModified</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="TransformationIsHierarchical" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="a6087c19-3262-4b37-9fd2-f3d2c135f260" visibility="none" reftype="Required"><properties><defaultvalue>false</defaultvalue><fieldcaption>TransformationIsHierarchical</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="TransformationHierarchicalXML" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="4099b257-bafc-402f-8096-71930c3453df" visibility="none" translatefield="true" reftype="Required"><properties><fieldcaption>TransformationHierarchicalXML</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field column="TransformationPreferredDocument" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="700" publicfield="false" guid="70e34180-8d0d-43c2-8c09-11d6d1e75af3" visibility="none" reftype="Required"><properties><fieldcaption>TransformationID</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field column="TransformationCustomizedColumns" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="400" publicfield="false" guid="38828384-fd05-43d1-8c0a-84508b70009b" reftype="Required"><settings><controlname>textboxcontrol</controlname></settings></field><field column="TransformationIsCustom" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="166f505a-37dd-40a8-95af-206c71699247" reftype="Required"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
WHERE [ClassName] LIKE 'cms.transformation'
END
GO


-- HFA 139 - System settings section was missing in Media gallery web part properties
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 8
BEGIN
UPDATE [CMS_WebPart]
SET [WebPartProperties]
= '<form version="2"><category name="Content"><properties><visible>True</visible></properties></category><field column="MediaLibraryName" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" publicfield="false" spellcheck="false" guid="293aa9f5-fe1f-4165-9d69-70bfac9a0c75" reftype="Required"><properties><fielddescription>Media library that content should be displayed.</fielddescription><fieldcaption>Media library</fieldcaption></properties><settings><controlname>medialibraryselector</controlname></settings></field><field column="MediaLibraryPath" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="450" publicfield="false" spellcheck="false" guid="3dc0bd00-404c-437c-aaa4-ddea1c06bcf8" visibility="none" reftype="Required" resolvedefaultvalue="False"><properties><fielddescription>Path to folder within the media library (CMSdesk -&gt; Tools -&gt; Media libraries -&gt; Files tab-&gt; &lt;node&gt;) which will be used as root folder in folder tree.</fielddescription><fieldcaption>Path</fieldcaption></properties><settings><controlname>TextBoxControl</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><Trim>False</Trim><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode></settings><rules><rule errormsg="The path must not contain special characters!">{%Rule("Value.Matches(\"^([^:*?&lt;&gt;{}\\\\\\\\\\\"|]*)+$\")", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"RegExp\" &gt;&lt;p n=\"regexp\"&gt;&lt;t&gt;^([^:*?&amp;lt;&amp;gt;{}\\\\&amp;quot;|]*)+$&lt;/t&gt;&lt;v&gt;^([^:*?&amp;lt;&amp;gt;{}\\\\&amp;quot;|]*)+$&lt;/v&gt;&lt;r&gt;0&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;text&lt;/vt&gt;&lt;tv&gt;0&lt;/tv&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")|(user)administrator|(hash)f034e39492756b5968a25b13d7b7c7cd60fd20e51d5f437319696e628ce5079a%}</rule></rules></field><field column="ShowSubfoldersContent" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="589866ed-e9f1-4168-baa3-dd619d9170d4" reftype="Required"><properties><fielddescription>Indicates if subfolders content should be displayed.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Show subfolders content</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="DisplayFileCount" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="8918bba0-804c-4d3b-a5de-348864797da9" visibility="none" reftype="Required"><properties><fielddescription>Indicates if file count in directory should be displayed in folder tree.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Display file count</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="DisplayActiveContent" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="76b0b198-c521-4f52-93b1-a89c9b10e8ec" reftype="Required"><properties><fielddescription>Indicates if active content (video, flash etc.) should be displayed.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Display active content</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="IconSet" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="50c77bb6-d535-43a7-ad30-7a1dd660ab6e" visibility="none" reftype="Required"><properties><fielddescription>Name of icon set used for file preview. By default, icons are taken from ~\CMS\App_Themes\Default\Images\FileIcons\ folder. If you specify an icon set name, icons will be taken from ~\CMS\App_Themes\Default\Images\FileIcons\&lt;IconSetName&gt; folder.</fielddescription><fieldcaption>Icon set name</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="HideFolderTree" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="6bb8c7a2-505f-4350-a2a9-0e5d34a87192" reftype="Required"><properties><fielddescription>Indicates if folder tree should be displayed.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide folder tree</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseSecureLinks" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="0902f088-f354-47ea-853d-6629bbb61312" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the links should point to the secure page. Permissions for displaying the media file are then checked if required by library settings.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Use secure links</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="Upload settings"><properties><visible>True</visible></properties></category><field column="AllowUpload" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="f42c7086-228e-4b90-97dd-46980698d5ea" reftype="Required"><properties><fielddescription>Indicates if file upload form should be displayed.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Allow upload</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="AllowUploadPreview" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="e051948d-2ef8-45fb-859d-a108acf89876" visibility="none" reftype="Required"><properties><fielddescription>Indicates if thumbnail file upload should be displayed in upload form.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Allow upload thumbnail</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="Content transformations"><properties><visible>True</visible></properties></category><field column="TransformationName" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="250" publicfield="false" spellcheck="false" guid="277f45dd-55a0-4efd-8cf1-abfd93e2b203" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.transformation$}</fielddescription><defaultvalue>Community.Transformations.MediaLibrary</defaultvalue><fieldcaption>Transformation name</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="SelectedItemTransformation" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" spellcheck="false" guid="9aae5de6-72d8-4728-a2c3-1e75e8792d2b" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.selectedtransf$}</fielddescription><defaultvalue>Community.Transformations.MediaLibrarySelectedItem</defaultvalue><fieldcaption>Selected item transformation</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="SeparatorTransformation" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" spellcheck="false" guid="cb003146-32a0-4049-8f6d-27a6730ae4ca" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.separatortransform$}</fielddescription><defaultvalue>Community.Transformations.MediaLibraryItemSeparator</defaultvalue><fieldcaption>Item separator transformation</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="HeaderTransformation" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" spellcheck="false" guid="514de162-52a7-4e32-b1cd-0b70358c0a9c" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.headertransform$}</fielddescription><fieldcaption>Header transformation</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="FooterTransformation" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" spellcheck="false" guid="5819d8b9-3d70-419b-aa93-928842ecc9ad" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.footertransform$}</fielddescription><fieldcaption>Footer transformation</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><category name="Filter settings"><properties><visible>True</visible></properties></category><field column="FilterMethod" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="c767c447-7ffa-4848-83db-a38c3746fa34" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether pager uses querystring parameter or postback.</fielddescription><fieldcaption>Filter method</fieldcaption></properties><settings><options>&lt;item value="0" text="Query parameter" /&gt;&lt;item value="1" text="Postback" /&gt;</options><controlname>dropdownlistcontrol</controlname></settings></field><field column="SortQueryStringKey" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" publicfield="false" spellcheck="false" guid="7e92bd8e-041c-4a13-999e-db037b993f97" visibility="none" reftype="Required"><properties><fielddescription>Name of sort by query parameter.</fielddescription><defaultvalue>sort</defaultvalue><fieldcaption>Sort direction querystring key</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="FileIDQueryStringKey" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" publicfield="false" spellcheck="false" guid="cfbfc324-36b2-411d-9b0d-363fe85e59e6" visibility="none" reftype="Required"><properties><fielddescription>Name of file id query parameter.</fielddescription><defaultvalue>fileid</defaultvalue><fieldcaption>File id querystring key</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="PathQueryStringKey" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" publicfield="false" spellcheck="false" guid="298d6234-3b90-4ed8-9c0b-b6a6a41c0863" visibility="none" reftype="Required"><properties><fielddescription>Name of path query paramter.</fielddescription><defaultvalue>path</defaultvalue><fieldcaption>Folder path querystring key</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><category name="Content filter"><properties><visible>True</visible></properties></category><field column="SelectTopN" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="9371a731-45c7-4ef0-ad74-6a140c776738" reftype="Required"><properties><fielddescription>Selects only top N files. If blank, all files are selected.</fielddescription><fieldcaption>Select top N files</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><category name="Pager"><properties><visible>True</visible></properties></category><field column="PageSize" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="0837a346-6aaa-4c4e-a9ca-415bee2a893e" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.pagesize$}</fielddescription><defaultvalue>10</defaultvalue><fieldcaption>Page size</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="QueryStringKey" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" publicfield="false" spellcheck="false" guid="5dc2a390-b43d-46ec-ac1f-2e5d2cde0937" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.querystring$}</fielddescription><defaultvalue>page</defaultvalue><fieldcaption>Querystring key</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="GroupSize" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="a0d84f46-f74b-4e56-a1b7-5e2f74af8676" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.groupsize$}</fielddescription><defaultvalue>10</defaultvalue><fieldcaption>Group size</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="DisplayFirstLastAutomatically" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="8f016ea2-eb5a-4150-8feb-a0369eea2a6b" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.displayfirstlastautomatically$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Display first &amp; last automatically</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="DisplayPreviousNextAutomatically" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="b2d66abe-d4b0-4de4-b9ea-35cd6693aba5" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.displaypreviousnextautomatically$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Display previous &amp; next automatically</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HidePagerForSinglePage" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="eef7a9ed-77e9-4d1f-8ff7-e73154d8d584" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.hidepagerforsinglepage$}</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Hide pager for single page</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="Pager design"><properties><visible>True</visible></properties></category><field column="Pages" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="be9b47ee-0737-4d22-94ef-e94342a07684" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.pages$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-Pages</defaultvalue><fieldcaption>Pages</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="CurrentPage" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="541cc8fc-3a86-4aaa-b376-e2fca5211d7f" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.currentpage$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-CurrentPage</defaultvalue><fieldcaption>CurrentPage</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="PageSeparator" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="812b3db6-235c-42c4-9888-4cd77c6891de" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.pageseparator$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-PageSeparator</defaultvalue><fieldcaption>Page separator</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="FirstPage" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="1a822d56-9c04-4d53-a03e-c0d8b0d90f8d" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.firstpage$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-FirstPage</defaultvalue><fieldcaption>First page</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="LastPage" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="e9029c10-7c64-48e5-926e-26b907127251" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.lastpage$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-LastPage</defaultvalue><fieldcaption>Last page</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="PreviousPage" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="c5368f1c-e879-4869-84ff-36ab690fbb45" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.previouspage$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-PreviousPage</defaultvalue><fieldcaption>Previous page</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="NextPage" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="9f95b58b-513e-4836-812f-79bff8686e9d" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.nextpage$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-NextPage</defaultvalue><fieldcaption>Next page</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="PreviousGroup" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="4d793c69-f6e2-4573-a727-3271297f7595" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.previousgroup$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-PreviousGroup</defaultvalue><fieldcaption>Previous group</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="NextGroup" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="6f592d93-54fe-4464-8a5e-b355ce1b3b76" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.nextgroup$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-NextGroup</defaultvalue><fieldcaption>Next group</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><field column="PagerLayout" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="77b63e71-735a-4e58-a5c2-7b82f60cc9c0" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.pagerlayout$}</fielddescription><defaultvalue>CMS.PagerTransformations.General-PagerLayout</defaultvalue><fieldcaption>Pager layout</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><category name="System settings" visible="True" /><field column="CheckPermissions" fieldcaption="Check permissions" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" fielddescription="{$documentation.webpartproperties.datasourcecheckperm$}" publicfield="false" spellcheck="false" guid="15ddb7b5-cef5-4d50-84f2-2ff6d1dbb28a" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="CacheItemName" fieldcaption="Cache item name" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" fielddescription="{$documentation.webpartproperties.cacheitemname$}" publicfield="false" spellcheck="false" guid="6f537b3b-78cd-4117-a623-f6eeaa465e12"><settings><controlname>textboxcontrol</controlname></settings></field><field column="CacheMinutes" fieldcaption="Cache minutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.cacheminutes$}" publicfield="false" spellcheck="false" guid="9c27db1a-15dc-4bcd-9b49-594e929804c3"><settings><controlname>textboxcontrol</controlname></settings></field><field column="CacheDependencies" fieldcaption="Cache dependencies" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.cachedependencies$}" publicfield="false" guid="e538e91e-dbdd-4d10-aec8-51acfc3760d3" visibility="none"><settings><controlname>cachedependencies</controlname></settings></field><category name="No data behavior"><properties><visible>True</visible></properties></category><field column="HideControlForZeroRows" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="9cf0c080-dd11-47b2-b926-a6554f1ebd65" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.hidenofound$}</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Hide if no record found</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="ZeroRowsText" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="d2bad3f1-587c-4b4c-bc3b-26687eb50330" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.norecordtext$}</fielddescription><defaultvalue>No data found</defaultvalue><fieldcaption>No record found text</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field></form>'
WHERE [WebPartName] LIKE 'MediaGallery'
END
GO


-- HFA-149 Ecommerce.GlobalShippingOptions.TaxClasses UIelement objectType was set to wrong value
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 8
BEGIN
UPDATE [CMS_UIElement]
SET [ElementProperties]
= '<data><displaybreadcrumbs>False</displaybreadcrumbs><includejquery>False</includejquery></data>'
WHERE [ElementName] LIKE 'Ecommerce.GlobalShippingOptions.TaxClasses'
END
GO

-- HFA 148 - Macro IsInPersona does not work outside request context (e.g in Marketing automation)
UPDATE [CMS_MacroRule]
SET [MacroRuleCondition] = '{_is}Contact.IsInPersona("{personaGuid}")'
WHERE [MacroRuleGUID] = '7D3E93DC-D4D4-4450-B9E7-CF8F559DAF2B'
GO

-- HFA-185 Hide Layout tab for Mixed templates
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 11
BEGIN
	UPDATE [CMS_UIElement] 
	SET [ElementVisibilityCondition] = '{%EditedObject.HasDesignMode && (EditedObject.PageTemplateType != "aspxportal")|(user)administrator|(hash)dd2e0f3fbb27092a186275fd4234cab4e39a4154741cc7c7ae84ffac770b31d9%}' 
	WHERE [ElementGUID] = '2ede349a-f971-4c4c-bce0-7df3ec9466e6'
END
GO


-- HFA-230 - Some scheduled tasks do not reflect their module
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 13
BEGIN
	DECLARE @newsletterResourceID int;
	SET @newsletterResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceName] = 'CMS.Newsletter')
	IF @newsletterResourceID <> 0 BEGIN
		UPDATE [CMS_ScheduledTask] SET [TaskResourceID] = @newsletterResourceID WHERE [TaskName] = 'Newsletter.CheckBounces';
	END
	
	DECLARE @onlineMarketingResourceID int;
	SET @onlineMarketingResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceName] = 'CMS.OnlineMarketing')
	IF @onlineMarketingResourceID <> 0 BEGIN
		UPDATE [CMS_ScheduledTask] SET [TaskResourceID] = @onlineMarketingResourceID WHERE [TaskName] = 'DeleteInactiveContacts';
	END
	
	DECLARE @webAnalyticsResourceID int;
	SET @webAnalyticsResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceName] = 'CMS.WebAnalytics')
	IF @webAnalyticsResourceID <> 0 BEGIN
		UPDATE [CMS_ScheduledTask] SET [TaskResourceID] = @webAnalyticsResourceID WHERE [TaskName] = 'Analytics.LogProcessing';
	END
END
GO

-- HFA-228 - Update getboardlist query in order to apply provided ORDER BY clause
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 14
BEGIN

UPDATE [CMS_Query] SET [QueryText] = 'SELECT ##TOPN## ##COLUMNS## FROM Board_Board 
JOIN View_CMS_Tree_Joined ON (BoardDocumentID = DocumentID) WHERE (NodeLinkedNodeID IS NULL) AND (##WHERE##) ORDER BY ##ORDERBY##' where [QueryText] = 'SELECT ##TOPN## ##COLUMNS## FROM Board_Board 
JOIN View_CMS_Tree_Joined ON (BoardDocumentID = DocumentID) AND (NodeLinkedNodeID IS NULL) AND ##WHERE##' AND [QueryName] = 'getboardlist'

END
GO
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '17' WHERE KeyName = N'CMSHotfixVersion'
GO
