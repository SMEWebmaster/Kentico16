CREATE PROCEDURE [Proc_CMS_WebFarmTask_Insert]
@TaskType nvarchar(50), 
@TaskTextData ntext, 
@TaskCreated datetime,
@TaskMachineName nvarchar(450),
@TaskTarget nvarchar(450),
@TaskBinary image,
@TaskIsAnonymous bit,
@TargetServerId int,
@CurrentServerId int
AS
BEGIN
	DECLARE @taskId int;
	BEGIN TRANSACTION
		INSERT INTO [CMS_WebFarmTask] ( [TaskType], [TaskTextData], [TaskBinaryData], [TaskCreated], [TaskEnabled], [TaskMachineName], [TaskTarget], [TaskIsAnonymous]) VALUES ( @TaskType, @TaskTextData, @TaskBinary, @TaskCreated, 1, @TaskMachineName, @TaskTarget, @TaskIsAnonymous ); 
		SELECT @taskId = SCOPE_IDENTITY();
	
		IF(@TaskIsAnonymous = 0) BEGIN
			IF(@TargetServerId > 0) BEGIN
				INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] ) VALUES ( @TargetServerId, @taskId );
			END
			ELSE BEGIN
				INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] ) SELECT ServerID, @taskId FROM [CMS_WebFarmServer] WHERE ServerID <> @CurrentServerId;
			END
		END
	COMMIT
END
