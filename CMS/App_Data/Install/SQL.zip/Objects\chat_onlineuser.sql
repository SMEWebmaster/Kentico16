CREATE TABLE [Chat_OnlineUser] (
		[ChatOnlineUserID]               [int] IDENTITY(1, 1) NOT NULL,
		[ChatOnlineUserSiteID]           [int] NOT NULL,
		[ChatOnlineUserLastChecking]     [datetime2](7) NULL,
		[ChatOnlineUserChatUserID]       [int] NOT NULL,
		[ChatOnlineUserJoinTime]         [datetime2](7) NULL,
		[ChatOnlineUserLeaveTime]        [datetime2](7) NULL,
		[ChatOnlineUserToken]            [nvarchar](50) NULL,
		[ChatOnlineUserIsHidden]         [bit] NOT NULL,
		CONSTRAINT [UQ_Chat_OnlineUser_SiteID-ChatUserID]
		UNIQUE
		NONCLUSTERED
		([ChatOnlineUserChatUserID], [ChatOnlineUserSiteID])
		
) 
ALTER TABLE [Chat_OnlineUser]
	ADD
	CONSTRAINT [PK_Chat_OnlineUser]
	PRIMARY KEY
	CLUSTERED
	([ChatOnlineUserID])
	
ALTER TABLE [Chat_OnlineUser]
	ADD
	CONSTRAINT [DEFAULT_Chat_OnlineUser_ChatOnlineUserIsHidden]
	DEFAULT ((0)) FOR [ChatOnlineUserIsHidden]
CREATE NONCLUSTERED INDEX [IX_Chat_OnlineUser_ChatOnlineUserChatUserID]
	ON [Chat_OnlineUser] ([ChatOnlineUserChatUserID]) 
CREATE NONCLUSTERED INDEX [IX_Chat_OnlineUser_SiteID]
	ON [Chat_OnlineUser] ([ChatOnlineUserSiteID]) 

ALTER TABLE [Chat_OnlineUser]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_OnlineUser_CMS_Site]
	FOREIGN KEY ([ChatOnlineUserSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [Chat_OnlineUser]
	CHECK CONSTRAINT [FK_Chat_OnlineUser_CMS_Site]
ALTER TABLE [Chat_OnlineUser]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_OnlineUser_Chat_User]
	FOREIGN KEY ([ChatOnlineUserChatUserID]) REFERENCES [Chat_User] ([ChatUserID])
ALTER TABLE [Chat_OnlineUser]
	CHECK CONSTRAINT [FK_Chat_OnlineUser_Chat_User]
