CREATE TABLE [Chat_RoomUser] (
		[ChatRoomUserID]                   [int] IDENTITY(1, 1) NOT NULL,
		[ChatRoomUserRoomID]               [int] NOT NULL,
		[ChatRoomUserChatUserID]           [int] NOT NULL,
		[ChatRoomUserLastChecking]         [datetime2](7) NULL,
		[ChatRoomUserKickExpiration]       [datetime2](7) NULL,
		[ChatRoomUserJoinTime]             [datetime2](7) NULL,
		[ChatRoomUserLeaveTime]            [datetime2](7) NULL,
		[ChatRoomUserAdminLevel]           [int] NOT NULL,
		[ChatRoomUserLastModification]     [datetime2](7) NOT NULL
) 
ALTER TABLE [Chat_RoomUser]
	ADD
	CONSTRAINT [PK_CMS_ChatRoomUser]
	PRIMARY KEY
	CLUSTERED
	([ChatRoomUserID])
	
ALTER TABLE [Chat_RoomUser]
	ADD
	CONSTRAINT [DEFAULT_Chat_RoomUser_ChatRoomUserAdminLevel]
	DEFAULT ((0)) FOR [ChatRoomUserAdminLevel]
ALTER TABLE [Chat_RoomUser]
	ADD
	CONSTRAINT [DEFAULT_Chat_RoomUser_ChatRoomUserChatUserID]
	DEFAULT ((0)) FOR [ChatRoomUserChatUserID]
ALTER TABLE [Chat_RoomUser]
	ADD
	CONSTRAINT [DEFAULT_Chat_RoomUser_ChatRoomUserLastModification]
	DEFAULT ('11/10/2011 3:29:00 PM') FOR [ChatRoomUserLastModification]
ALTER TABLE [Chat_RoomUser]
	ADD
	CONSTRAINT [DEFAULT_Chat_RoomUser_ChatRoomUserRoomID]
	DEFAULT ((0)) FOR [ChatRoomUserRoomID]
CREATE NONCLUSTERED INDEX [IX_Chat_RoomUser_ChatRoomUserChatUserID]
	ON [Chat_RoomUser] ([ChatRoomUserChatUserID]) 
CREATE NONCLUSTERED INDEX [IX_Chat_RoomUser_ChatRoomUserRoomID]
	ON [Chat_RoomUser] ([ChatRoomUserRoomID]) 
CREATE UNIQUE NONCLUSTERED INDEX [UQ_Chat_RoomUser_RoomID-ChatUserID]
	ON [Chat_RoomUser] ([ChatRoomUserRoomID], [ChatRoomUserChatUserID]) 

ALTER TABLE [Chat_RoomUser]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_RoomUser_Chat_Room]
	FOREIGN KEY ([ChatRoomUserRoomID]) REFERENCES [Chat_Room] ([ChatRoomID])
ALTER TABLE [Chat_RoomUser]
	CHECK CONSTRAINT [FK_Chat_RoomUser_Chat_Room]
ALTER TABLE [Chat_RoomUser]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_RoomUser_Chat_User]
	FOREIGN KEY ([ChatRoomUserChatUserID]) REFERENCES [Chat_User] ([ChatUserID])
ALTER TABLE [Chat_RoomUser]
	CHECK CONSTRAINT [FK_Chat_RoomUser_Chat_User]
