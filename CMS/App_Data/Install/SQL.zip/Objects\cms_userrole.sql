CREATE TABLE [CMS_UserRole] (
		[UserID]         [int] NOT NULL,
		[RoleID]         [int] NOT NULL,
		[ValidTo]        [datetime2](7) NULL,
		[UserRoleID]     [int] IDENTITY(1, 1) NOT NULL
) 
ALTER TABLE [CMS_UserRole]
	ADD
	CONSTRAINT [PK_CMS_UserRole]
	PRIMARY KEY
	CLUSTERED
	([UserRoleID])
	
ALTER TABLE [CMS_UserRole]
	ADD
	CONSTRAINT [DEFAULT_CMS_UserRole_RoleID]
	DEFAULT ((0)) FOR [RoleID]
ALTER TABLE [CMS_UserRole]
	ADD
	CONSTRAINT [DEFAULT_CMS_UserRole_UserID]
	DEFAULT ((0)) FOR [UserID]
CREATE NONCLUSTERED INDEX [IX_CMS_UserRole_RoleID]
	ON [CMS_UserRole] ([RoleID]) 
CREATE NONCLUSTERED INDEX [IX_CMS_UserRole_UserID]
	ON [CMS_UserRole] ([RoleID], [ValidTo], [UserID]) 
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_UserRole_UserID_RoleID]
	ON [CMS_UserRole] ([UserID], [RoleID]) 

ALTER TABLE [CMS_UserRole]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_UserRole_RoleID_CMS_Role]
	FOREIGN KEY ([RoleID]) REFERENCES [CMS_Role] ([RoleID])
ALTER TABLE [CMS_UserRole]
	CHECK CONSTRAINT [FK_CMS_UserRole_RoleID_CMS_Role]
ALTER TABLE [CMS_UserRole]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_UserRole_UserID_CMS_User]
	FOREIGN KEY ([UserID]) REFERENCES [CMS_User] ([UserID])
ALTER TABLE [CMS_UserRole]
	CHECK CONSTRAINT [FK_CMS_UserRole_UserID_CMS_User]
