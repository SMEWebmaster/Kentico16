CREATE TABLE [CMS_WebFarmServer] (
		[ServerID]               [int] IDENTITY(1, 1) NOT NULL,
		[ServerDisplayName]      [nvarchar](300) NOT NULL,
		[ServerName]             [nvarchar](300) NOT NULL,
		[ServerURL]              [nvarchar](256) NOT NULL,
		[ServerGUID]             [uniqueidentifier] NULL,
		[ServerLastModified]     [datetime2](7) NOT NULL,
		[ServerEnabled]          [bit] NULL
) 
ALTER TABLE [CMS_WebFarmServer]
	ADD
	CONSTRAINT [PK_CMS_WebFarmServer]
	PRIMARY KEY
	NONCLUSTERED
	([ServerID])
	
ALTER TABLE [CMS_WebFarmServer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerDisplayName]
	DEFAULT (N'') FOR [ServerDisplayName]
ALTER TABLE [CMS_WebFarmServer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerEnabled]
	DEFAULT ((0)) FOR [ServerEnabled]
ALTER TABLE [CMS_WebFarmServer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerLastModified]
	DEFAULT ('9/17/2013 12:18:06 PM') FOR [ServerLastModified]
ALTER TABLE [CMS_WebFarmServer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerName]
	DEFAULT (N'') FOR [ServerName]
ALTER TABLE [CMS_WebFarmServer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerURL]
	DEFAULT (N'') FOR [ServerURL]
CREATE CLUSTERED INDEX [IX_CMS_WebFarmServer_ServerDisplayName]
	ON [CMS_WebFarmServer] ([ServerDisplayName]) 
CREATE NONCLUSTERED INDEX [IX_CMS_WebFarmServer_ServerName]
	ON [CMS_WebFarmServer] ([ServerName]) 

