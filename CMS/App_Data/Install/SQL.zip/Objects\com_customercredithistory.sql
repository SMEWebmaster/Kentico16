CREATE TABLE [COM_CustomerCreditHistory] (
		[EventID]                     [int] IDENTITY(1, 1) NOT NULL,
		[EventName]                   [nvarchar](200) NOT NULL,
		[EventCreditChange]           [float] NOT NULL,
		[EventDate]                   [datetime2](7) NOT NULL,
		[EventDescription]            [nvarchar](max) NULL,
		[EventCustomerID]             [int] NOT NULL,
		[EventCreditGUID]             [uniqueidentifier] NULL,
		[EventCreditLastModified]     [datetime2](7) NOT NULL,
		[EventSiteID]                 [int] NULL
)  
ALTER TABLE [COM_CustomerCreditHistory]
	ADD
	CONSTRAINT [PK_COM_CustomerCreditHistory]
	PRIMARY KEY
	NONCLUSTERED
	([EventID])
	
ALTER TABLE [COM_CustomerCreditHistory]
	ADD
	CONSTRAINT [DEFAULT_COM_CustomerCreditHistory_EventCreditChange]
	DEFAULT ((0)) FOR [EventCreditChange]
ALTER TABLE [COM_CustomerCreditHistory]
	ADD
	CONSTRAINT [DEFAULT_COM_CustomerCreditHistory_EventCreditLastModified]
	DEFAULT ('9/26/2012 12:21:38 PM') FOR [EventCreditLastModified]
ALTER TABLE [COM_CustomerCreditHistory]
	ADD
	CONSTRAINT [DEFAULT_COM_CustomerCreditHistory_EventDate]
	DEFAULT ('9/27/2012 2:48:56 PM') FOR [EventDate]
ALTER TABLE [COM_CustomerCreditHistory]
	ADD
	CONSTRAINT [DEFAULT_COM_CustomerCreditHistory_EventName]
	DEFAULT ('') FOR [EventName]
CREATE NONCLUSTERED INDEX [IX_COM_CustomerCreditHistory_EventCustomerID]
	ON [COM_CustomerCreditHistory] ([EventCustomerID]) 
CREATE CLUSTERED INDEX [IX_COM_CustomerCreditHistory_EventCustomerID_EventDate]
	ON [COM_CustomerCreditHistory] ([EventCustomerID], [EventDate] DESC) 
CREATE NONCLUSTERED INDEX [IX_COM_CustomerCreditHistory_EventSiteID]
	ON [COM_CustomerCreditHistory] ([EventSiteID]) 

ALTER TABLE [COM_CustomerCreditHistory]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_CustomerCreditHistory_EventCustomerID_COM_Customer]
	FOREIGN KEY ([EventCustomerID]) REFERENCES [COM_Customer] ([CustomerID])
ALTER TABLE [COM_CustomerCreditHistory]
	CHECK CONSTRAINT [FK_COM_CustomerCreditHistory_EventCustomerID_COM_Customer]
ALTER TABLE [COM_CustomerCreditHistory]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_CustomerCreditHistory_EventSiteID_CMS_Site]
	FOREIGN KEY ([EventSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_CustomerCreditHistory]
	CHECK CONSTRAINT [FK_COM_CustomerCreditHistory_EventSiteID_CMS_Site]
