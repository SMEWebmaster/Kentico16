CREATE TABLE [Notification_Gateway] (
		[GatewayID]                    [int] IDENTITY(1, 1) NOT NULL,
		[GatewayName]                  [nvarchar](200) NOT NULL,
		[GatewayDisplayName]           [nvarchar](200) NOT NULL,
		[GatewayAssemblyName]          [nvarchar](200) NOT NULL,
		[GatewayClassName]             [nvarchar](200) NOT NULL,
		[GatewayDescription]           [nvarchar](max) NULL,
		[GatewaySupportsEmail]         [bit] NULL,
		[GatewaySupportsPlainText]     [bit] NULL,
		[GatewaySupportsHTMLText]      [bit] NULL,
		[GatewayLastModified]          [datetime2](7) NOT NULL,
		[GatewayGUID]                  [uniqueidentifier] NOT NULL,
		[GatewayEnabled]               [bit] NULL
)  
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [PK_Notification_Gateway]
	PRIMARY KEY
	NONCLUSTERED
	([GatewayID])
	
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewayAssemblyName]
	DEFAULT ('') FOR [GatewayAssemblyName]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewayClassName]
	DEFAULT ('') FOR [GatewayClassName]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewayDisplayName]
	DEFAULT ('') FOR [GatewayDisplayName]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewayEnabled]
	DEFAULT ((0)) FOR [GatewayEnabled]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewayName]
	DEFAULT ('') FOR [GatewayName]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewaySupportsEmail]
	DEFAULT ((0)) FOR [GatewaySupportsEmail]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewaySupportsHTMLText]
	DEFAULT ((0)) FOR [GatewaySupportsHTMLText]
ALTER TABLE [Notification_Gateway]
	ADD
	CONSTRAINT [DEFAULT_Notification_Gateway_GatewaySupportsPlainText]
	DEFAULT ((0)) FOR [GatewaySupportsPlainText]
CREATE CLUSTERED INDEX [IX_Notification_Gateway_GatewayDisplayName]
	ON [Notification_Gateway] ([GatewayDisplayName]) 

