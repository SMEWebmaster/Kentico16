CREATE TABLE [Personas_Persona] (
		[PersonaID]                      [int] IDENTITY(1, 1) NOT NULL,
		[PersonaDisplayName]             [nvarchar](200) NOT NULL,
		[PersonaName]                    [nvarchar](200) NOT NULL,
		[PersonaDescription]             [nvarchar](max) NULL,
		[PersonaEnabled]                 [bit] NOT NULL,
		[PersonaGUID]                    [uniqueidentifier] NOT NULL,
		[PersonaSiteID]                  [int] NOT NULL,
		[PersonaScoreID]                 [int] NOT NULL,
		[PersonaPictureMetafileGUID]     [uniqueidentifier] NULL,
		[PersonaPointsThreshold]         [int] NOT NULL
)  
ALTER TABLE [Personas_Persona]
	ADD
	CONSTRAINT [PK_Personas_Persona]
	PRIMARY KEY
	CLUSTERED
	([PersonaID])
	
ALTER TABLE [Personas_Persona]
	ADD
	CONSTRAINT [DEFAULT_Personas_Persona_PersonaDisplayName]
	DEFAULT (N'') FOR [PersonaDisplayName]
ALTER TABLE [Personas_Persona]
	ADD
	CONSTRAINT [DEFAULT_Personas_Persona_PersonaEnabled]
	DEFAULT ((1)) FOR [PersonaEnabled]
ALTER TABLE [Personas_Persona]
	ADD
	CONSTRAINT [DEFAULT_Personas_Persona_PersonaName]
	DEFAULT (N'[_][_]AUTO[_][_]') FOR [PersonaName]
ALTER TABLE [Personas_Persona]
	ADD
	CONSTRAINT [DEFAULT_Personas_Persona_PersonaPointsThreshold]
	DEFAULT ((100)) FOR [PersonaPointsThreshold]
ALTER TABLE [Personas_Persona]
	ADD
	CONSTRAINT [DEFAULT_Personas_Persona_PersonaScoreID]
	DEFAULT ((0)) FOR [PersonaScoreID]
CREATE NONCLUSTERED INDEX [IX_Personas_Persona_PersonaScoreID]
	ON [Personas_Persona] ([PersonaScoreID]) 
CREATE NONCLUSTERED INDEX [IX_Personas_Persona_PersonaSiteID]
	ON [Personas_Persona] ([PersonaSiteID]) 

ALTER TABLE [Personas_Persona]
	WITH CHECK
	ADD CONSTRAINT [FK_Personas_Persona_CMS_Site]
	FOREIGN KEY ([PersonaSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [Personas_Persona]
	CHECK CONSTRAINT [FK_Personas_Persona_CMS_Site]
