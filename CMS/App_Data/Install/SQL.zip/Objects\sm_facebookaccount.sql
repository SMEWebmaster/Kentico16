CREATE TABLE [SM_FacebookAccount] (
		[FacebookAccountID]                            [int] IDENTITY(1, 1) NOT NULL,
		[FacebookAccountGUID]                          [uniqueidentifier] NOT NULL,
		[FacebookAccountLastModified]                  [datetime2](7) NOT NULL,
		[FacebookAccountSiteID]                        [int] NOT NULL,
		[FacebookAccountName]                          [nvarchar](200) NOT NULL,
		[FacebookAccountDisplayName]                   [nvarchar](200) NOT NULL,
		[FacebookAccountPageID]                        [nvarchar](500) NOT NULL,
		[FacebookAccountPageAccessToken]               [nvarchar](max) NOT NULL,
		[FacebookAccountFacebookApplicationID]         [int] NOT NULL,
		[FacebookAccountPageAccessTokenExpiration]     [datetime2](7) NULL,
		[FacebookAccountPageUrl]                       [nvarchar](1000) NULL,
		[FacebookAccountIsDefault]                     [bit] NULL
)  
ALTER TABLE [SM_FacebookAccount]
	ADD
	CONSTRAINT [PK_SM_FacebookAccount]
	PRIMARY KEY
	CLUSTERED
	([FacebookAccountID])
	
ALTER TABLE [SM_FacebookAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_FacebookAccount_FacebookAccountFacebookApplicationID]
	DEFAULT ((0)) FOR [FacebookAccountFacebookApplicationID]
ALTER TABLE [SM_FacebookAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_FacebookAccount_FacebookAccountPageAccessToken]
	DEFAULT ('') FOR [FacebookAccountPageAccessToken]
ALTER TABLE [SM_FacebookAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_FacebookAccount_FacebookAccountPageID]
	DEFAULT ('') FOR [FacebookAccountPageID]
CREATE NONCLUSTERED INDEX [IX_SM_FacebookAccount_FacebookAccountFacebookApplicationID]
	ON [SM_FacebookAccount] ([FacebookAccountFacebookApplicationID]) 
CREATE NONCLUSTERED INDEX [IX_SM_FacebookAccount_FacebookAccountSiteID]
	ON [SM_FacebookAccount] ([FacebookAccountSiteID]) 

ALTER TABLE [SM_FacebookAccount]
	WITH CHECK
	ADD CONSTRAINT [FK_SM_FacebookAccount_CMS_Site]
	FOREIGN KEY ([FacebookAccountSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [SM_FacebookAccount]
	CHECK CONSTRAINT [FK_SM_FacebookAccount_CMS_Site]
ALTER TABLE [SM_FacebookAccount]
	WITH CHECK
	ADD CONSTRAINT [FK_SM_FacebookAccount_SM_FacebookApplication]
	FOREIGN KEY ([FacebookAccountFacebookApplicationID]) REFERENCES [SM_FacebookApplication] ([FacebookApplicationID])
ALTER TABLE [SM_FacebookAccount]
	CHECK CONSTRAINT [FK_SM_FacebookAccount_SM_FacebookApplication]
