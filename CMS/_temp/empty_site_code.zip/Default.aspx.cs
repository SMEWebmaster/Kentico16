﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
 
using System.Security.Cryptography;
using System.Text;
 using System.Data;
using System.Net;
using System.IO;
using SSO;
using Personify.WebControls.Base.Providers;
using IMS;


public partial class _Default : System.Web.UI.Page
{
    #region "Global Variables"

    private DataSet ds = new DataSet();

    private DataSet groupDs = new DataSet();

    private string ID, FirstName, LastName, Email, web_login, IsDisabled, MemberType = "", lastpage;

    private string DOMAIN = ".networkats.com";

    private string RolePrefix = "ats_";

    private string tokenid = "x";

    private const string PersonifySessionKey = "PersonifyToken";

    private readonly string _personifyImsUrl = ConfigurationManager.AppSettings["IMSWebReferenceURL"];

    private readonly string _personifySsoUrl = ConfigurationManager.AppSettings["personify.SSO.service"];

    private readonly string _personifySsoVendorBlock = ConfigurationManager.AppSettings["PersonifySSO_Block"];

    private readonly string _personifySsoVendorName = ConfigurationManager.AppSettings["PersonifySSO_VendorName"];

    private readonly string _personifySsoVendorPassword = ConfigurationManager.AppSettings["PersonifySSO_Password"];

    #endregion

    public service _wsSso = new service();


    protected void Page_Load(object sender, EventArgs e)
    {
          LoginMember("kral@smenet.org", "Password1", true);
        if (!Page.IsPostBack)
        {
            //    _wsSso = new service { Url = _personifySsoUrl };

            //    if (Request.QueryString["action"] == "logout")
            //    {
            //        //  var userApi = new UserAPI();
            //        //  Logout(userApi, Session[PersonifySessionKey] != null ? Session[PersonifySessionKey].ToString() : null);
            //        //  objKenticoService.Logout("");
            //        string returnUrl;

            //        if (Request.QueryString["returnUrl"] != null && !string.IsNullOrEmpty(Request.QueryString["returnUrl"]))
            //        {
            //            returnUrl = Request.QueryString["returnUrl"];
                if (Request.QueryString["ct"] != null)
            {
                string customerToken = Request.QueryString["ct"];

                string decryptedToken = DecryptCustomerToken(customerToken);
                string finalToken = "";
                if (decryptedToken != "")
                {
                    finalToken = ValidateCustomerToken(decryptedToken);
                }

                string customerIdentifier = "";
                string emailaddress = null;
                string userName = null;

                if (finalToken != "")
                {
                    customerIdentifier = ValidateUser(finalToken, ref emailaddress, ref userName);
                    Session["PersonifyToken"] = finalToken;
                    

                }

               
            }
        }
    }
  #region login
       private string ValidateUser(string ssoToken, ref string email, ref string userName)
    {
        var bCustomerExists = false;
        var timssIdentifier = "";

        var res = _wsSso.TIMSSCustomerIdentifierGet(_personifySsoVendorName, _personifySsoVendorPassword, ssoToken);

        if (!string.IsNullOrEmpty(res.CustomerIdentifier))
        {
            timssIdentifier = res.CustomerIdentifier;

            var customerResult = _wsSso.SSOCustomerGet(_personifySsoVendorName, _personifySsoVendorPassword,
                timssIdentifier);

            if (customerResult.Errors == null)
            {
                bCustomerExists = customerResult.UserExists;
                email = customerResult.Email;
                userName = customerResult.UserName;
            }
        }

        if (bCustomerExists)
        {
            return timssIdentifier;
        }
        //else
        //{
        //    var custres = _wsSso.SSOCustomerRegister(_personifySsoVendorName, _personifySsoVendorPassword, userName,
        //        "12345678", email, "test", "test" );
        //    var res2 = _wsSso.TIMSSCustomerIdentifierGet(_personifySsoVendorName, _personifySsoVendorPassword, ssoToken);
        //    timssIdentifier = res2.CustomerIdentifier;
        //    return timssIdentifier;
        //}

        return null;
    }

    private void LoginMember(string Username, string Password, bool RememberMember)
    {
        try
        {
            var vendorPassword =  ConfigurationManager.AppSettings["PersonifySSO_Password"].ToString();
            var vendorBlock =   ConfigurationManager.AppSettings["PersonifySSO_Block"].ToString();
            var vendorId = ConfigurationManager.AppSettings["PersonifySSO_VendorID"];

             var encryptedVendorToken = RijndaelAlgorithm.GetVendorToken(Request.Url.AbsoluteUri, vendorPassword,
               vendorBlock, Username, Password, RememberMember);

           
            string URL = string.Format("{0}?vi={1}&vt={2}", "http://smemitst.personifycloud.com/SSO/autologin.aspx", vendorId, encryptedVendorToken);
          //  var ssoRedirect = "http://smemitst.personifycloud.com/SSO/autologin.aspx" + "?vi=" + vendorId + "&vt=" + encryptedVendorToken;
            Response.Redirect(URL);
        }
        catch (Exception exception)
        {
            // ApplicationEngine.HandleException(exception);
            Response.Write(exception.ToString());
           // LoginUsertokentico.WriteError("LoginMember", exception.ToString());
           // EventLogProvider.LogException("LoginMember", "Get", exception);
        }
    }
    #endregion 
      private string[] GetImsroles(string masterCustomerId, int subCustomerId)
    {
        var timssId = masterCustomerId + "|" + subCustomerId;
        var roleList = new List<string>();

        using (var myim = new IMService { Url = _personifyImsUrl })
        {
            IMSCustomerRoleGetResult imsCustomerRoleGetResult = myim.IMSCustomerRoleGetByTimssCustomerId(_personifySsoVendorName, _personifySsoVendorPassword, timssId);

            if (imsCustomerRoleGetResult.CustomerRoles == null)
                return new[] { string.Empty };

            foreach (var roledetail in imsCustomerRoleGetResult.CustomerRoles)
            {

                roleList.Add(roledetail.Value);

            }

            return roleList.ToArray();
        }

    }
  private string ValidateCustomerToken(string customerToken)
    {
        var res = _wsSso.SSOCustomerTokenIsValid(_personifySsoVendorName, _personifySsoVendorPassword, customerToken);
        if (res.Valid && !string.IsNullOrEmpty(res.NewCustomerToken))
        {
            return res.NewCustomerToken;
        }
        return null;
    }
    private string DecryptCustomerToken(string customerToken)
    {
        try
        { 
            var res = _wsSso.CustomerTokenDecrypt(_personifySsoVendorName, _personifySsoVendorPassword,_personifySsoVendorBlock, customerToken);
            if (!string.IsNullOrEmpty(res.CustomerToken))
            {
                return res.CustomerToken;
            }
            else
            {
                return null;
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.ToString());
            return null;
        }
    }

    private string GetMD5HashData(string data)
    {
        //create new instance of md5
        MD5 md5 = MD5.Create();

        //convert the input text to array of bytes
        byte[] result = md5.ComputeHash(Encoding.Default.GetBytes(data));



         StringBuilder sb = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                sb.Append(result[i].ToString("X2"));
            }

            // And return it
            return sb.ToString();

        // return hexadecimal string
        //return returnValue.ToString();
    }
    
   
}